package com.ccb.portal.upchainaccount.dos.UpChainAccountDo;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.portal.upchainaccount.vo.UpChainAccountVo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.pub.ErrorCodeEnum;

public class UpChainAccountDo extends BaseMDo<UpChainAccountDo>{
    private Logger log = LoggerFactory.getLogger(UpChainAccountDo.class);
    
    private String accountID;
    
    private String accountName;
    
    private String exTaskID;
    
    private String resourceID;
    
    private String memberCode;
    
    private String memberName;
    
    private String bkNodeInfo;
    
    private String contractName;
    
    private String contractAddr;
    
    private String tableName;
    
    private String dbIP;
    
    private String dbName;
    
    private String dbPort;
    
    private String exTotalCnt;
    
    private String exFailCnt;
    
    private String exSuccCnt;
    
    private String stTime;
    
    private String endTime;
    
    private String exResult;
    
    private String cataType;
    
    private String isSaveChain;
    
    private String isConstnt;
    
    
    public String getAccountID() {
        return this.accountID;
    }

    public void setAccountID(String accountID) {
        this.accountID = accountID;
    }
    
    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }
    
    public String getExTaskID() {
        return exTaskID;
    }

    public void setExTaskID(String exTaskID) {
        this.exTaskID = exTaskID;
    }
    
    public String getResourceID() {
        return resourceID;
    }

    public void setResourceID(String resourceID) {
        this.resourceID = resourceID;
    }
    
    public String getMemberCode() {
        return memberCode;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }
    
    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }
    
    public String getBkNodeInfo() {
        return bkNodeInfo;
    }

    public void setBkNodeInfo(String bkNodeInfo) {
        this.bkNodeInfo = bkNodeInfo;
    }
    
    public String getContractName() {
        return contractName;
    }

    public void setContractName(String contractName) {
        this.contractName = contractName;
    }
    
    public String getContractAddr() {
        return contractAddr;
    }

    public void setContractAddr(String contractAddr) {
        this.contractAddr = contractAddr;
    }
    
    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    
    public String getDbIP() {
        return dbIP;
    }

    public void setDbIP(String dbIP) {
        this.dbIP = dbIP;
    }
    
    public String getDbName() {
        return dbName;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }
    
    public String getDbPort() {
        return dbPort;
    }

    public void setDbPort(String dbPort) {
        this.dbPort = dbPort;
    }
    
    public String getExTotalCnt() {
        return exTotalCnt;
    }

    public void setExTotalCnt(String exTotalCnt) {
        this.exTotalCnt = exTotalCnt;
    }
    
    public String getExFailCnt() {
        return exFailCnt;
    }

    public void setExFailCnt(String exFailCnt) {
        this.exFailCnt = exFailCnt;
    }
    
    public String getExSuccCnt() {
        return exSuccCnt;
    }

    public void setExSuccCnt(String exSuccCnt) {
        this.exSuccCnt = exSuccCnt;
    }
    
    public String getStTime() {
        return stTime;
    }

    public void setStTime(String stTime) {
        this.stTime = stTime;
    }
    
    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    
    public String getExResult() {
        return exResult;
    }

    public void setExResult(String exResult) {
        this.exResult = exResult;
    }
    
    public String getCataType() {
        return cataType;
    }

    public void setCataType(String cataType) {
        this.cataType = cataType;
    }
    
    public String getIsSaveChain() {
        return isSaveChain;
    }

    public void setIsSaveChain(String isSaveChain) {
        this.isSaveChain = isSaveChain;
    }
    
    public String getIsConstnt() {
        return isConstnt;
    }

    public void setIsConstnt(String isConstnt) {
        this.isConstnt = isConstnt;
    }
    

	public int insertUpChainAccount() throws Exception {
        int i = 0;
        try{
            i = _dao.insertBySqlMap_mybatis("portal.upChainAccount.insert", this);
        } catch (Exception e) {
            log.error("insert upChainAccount failure, message: {}", e.getMessage());
            throw new CommonRuntimeException(null, "插入xx数据失败");
        }
        return i;
	}

    public int queryDataCount(Map<String, Object> map) throws Exception {
        int count = 0;
        try{
            count = (Integer) _dao.findObjectBySqlMap_mybatis("portal.upChainAccount.queryCount", map);
        } catch (Exception ex) {
            log.error("queryDataCount upChainAccount failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(null, "查询xx数据失败");
        }
        return count;
	}

    public List<UpChainAccountVo> queryDataList(Map<String, Object> map) throws Exception {
        List<UpChainAccountVo> list = null;
        try{
            list = (List<UpChainAccountVo>) _dao.findListBySqlMap_mybatis("portal.upChainAccount.queryListByMap", map);
        } catch (Exception ex) {
            log.error("queryDataList upChainAccount failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(null, "查询xx数据失败");
        }
        return list;
	}

    public UpChainAccountVo queryDetail(Map<String, Object> map) throws Exception {
        List<UpChainAccountVo> list = null;
        try{
            list = (List<UpChainAccountVo>) _dao.findListBySqlMap_mybatis("portal.upChainAccount.queryListByMap", map);
        } catch (Exception ex) {
            log.error("queryDetail upChainAccount failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(null, "查询xx数据失败");
        }
        return list == null || list.size() == 0 ? null : list.get(0);
	}

    public UpChainAccountDo findById(String id) throws Exception {
        List<UpChainAccountDo> list = null;
        try{
            Map map = new HashMap();
            map.put("accountID", id);
            list = (List<UpChainAccountDo>) _dao.findListBySqlMap_mybatis("portal.upChainAccount.findById", map);
        } catch (Exception ex) {
            log.error("findById upChainAccount failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(null, "查询xx数据失败");
        }
        return list == null || list.size() == 0 ? null : list.get(0);
	}

    public void updateUpChainAccount(Map<String, String> map) throws Exception {
        try{
            _dao.updateBySqlMap_mybatis("portal.upChainAccount.updateByMap", map);
        } catch (Exception ex) {
            log.error("updateUpChainAccount upChainAccount failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(null, "更新xx数据失败");
        }
    }
        
}