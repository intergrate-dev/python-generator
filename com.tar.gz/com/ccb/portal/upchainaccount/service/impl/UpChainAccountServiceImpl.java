package com.ccb.portal.upchainaccount.service.impl;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import com.alibaba.fastjson.JSONObject;
import com.ccb.portal.upchainaccount.dos.UpChainAccountDo;
import com.ccb.portal.upchainaccount.vo.UpChainAccountVo;
import com.ccb.portal.upchainaccount.service.UpChainAccountService;
import com.ccb.portal.common.entity.ReqTxnCommCom;
import com.ccb.portal.common.entity.ResTxnCommCom;
import com.ccb.portal.common.validation.ValidateUtil;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.pub.ErrorCodeEnum;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("portal.UpChainAccountService")
public class UpChainAccountServiceImpl implements UpChainAccountService {
    private Logger log = LoggerFactory.getLogger(UpChainAccountServiceImpl.class);
    
    @Autowired
    UpChainAccountService upChainAccountService;
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String createUpChainAccount(String jsonString) throws Exception {
        UpChainAccountDo upChainAccountDo = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            upChainAccountDo = JSONObject.parseObject(body.getString("upChainAccount"), UpChainAccountDo.class);
            Map doMap = JSONObject.parseObject(body.getString("upChainAccount"), HashMap.class);
            // TODO, add items required
            List<String> items = new ArrayList<>();
            items.add("");
            // ValidateUtil.validParams(doMap, items);
            // TODO set accountID, 前端自己生成，还是后端提供接口生成
            // TODO set time
            upChainAccountDo.insertUpChainAccount();
            
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "创建成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("create upChainAccount occure exception, accountID: {}, error: {}", upChainAccountDo.getAccountID(), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "创建xx失败");
        }
    }
    
    @Override
    public String getList(String jsonString) throws Exception {
        try{
            this.checkReqParams(jsonString);
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            this.checkPage(common);
            ResTxnCommCom rtc = new ResTxnCommCom();
            rtc.setStsTraceId(common.getTStsTraceId());
            rtc.setTCurrTotalPage(common.getTPageJump());
            rtc.setTCurrTotalRec(common.getTRecInPage());
            Map<String, Object> map = new HashMap();
            Integer pageNo = Integer.valueOf(StringUtils.defaultIfEmpty(common.getTPageJump(), "1"))
            Integer pageSize = Integer.valueOf(StringUtils.defaultIfEmpty(common.getTRecInPage(), "10"))
            map.put("tPageJump", (pageNo - 1) * pageSize);
            map.put("tRecInPage", pageSize);
            UpChainAccountDo upChainAccountDo = new UpChainAccountDo();
            int total = upChainAccountDo.queryDataCount(map);
            List<UpChainAccountVo> dataList = upChainAccountDo.queryDataList(map);

            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            this.setPage(common, rtc, total);
            return getObject(rtc, dataList);
        } catch(Exception e) {
            log.info("getList upChainAccount occure exception, error: {}", e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询xx列表失败");
        }
    }

    @Override
    public String getDetail(String jsonString) throws Exception {
        String accountID = null;
        try{
            this.checkReqParams(jsonString);
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            accountID = body.getString("accountID");
            // ValidateUtil.checkIsValid("accountID", accountID);

            Map<String, Object> map = new HashMap<>();
            map.put("accountID", accountID);
            com.ccb.portal.upchainaccount.vo.UpChainAccountVo detail = new UpChainAccountDo().queryDetail(map);
            return getObject(jsonCommon, detail);
        } catch(Exception e) {
            log.info("getDetail upChainAccount occure exception, accountID: {}, error: {}", upChainAccountDo.getAccountID(), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询xx详情失败");
        }
    }
    
    public UpChainAccountDo getUpChainAccountById(String id) throws Exception {
        return new UpChainAccountDo().findById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String update(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            //upChainAccountDo = JSONObject.parseObject(body.getString("upChainAccount"), UpChainAccountDo.class);
            doMap = JSONObject.parseObject(body.getString("upChainAccount"), HashMap.class);
            // TODO, add items required
            List<String> items = new ArrayList<>();
            items.add("");
            // ValidateUtil.validParams(doMap, items);
            // TODO set time
            new UpChainAccountDo.updateUpChainAccount(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "修改成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("update upChainAccount occure exception, accountID: {}, error: {}", doMap.get("accountID"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "修改xx信息失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String publish(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("upChainAccount"), HashMap.class);
            doMap.put("state", "1");
            new UpChainAccountDo().updateUpChainAccount(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "发布成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("publish upChainAccount occure exception, accountID: {}, error: {}", doMap.get("accountID"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "发布xx失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String revocate(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            Map doMap = JSONObject.parseObject(body.getString("upChainAccount"), HashMap.class);
            doMap.put("state", "0");
            new UpChainAccountDo().updateUpChainAccount(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "注销成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("revocate upChainAccount occure exception, accountID: {}, error: {}", doMap.get("accountID"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "注销xx失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String delete(String jsonString) throws Exception {
        return null;
    }

}