package com.ccb.portal.datameta.vo.DatametaVo;

import java.util.List;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;

public class DatametaVo {
    private Logger log = LoggerFactory.getLogger(DatametaVo.class);
    
    
    private String datametaId;
    
    private String dtmetaCate;
    
    private String dtmetaDesc;
    
    private String dtmetaDomain;
    
    private String state;
    
    private String remark;
    
    private String dtmetaName;
    
    private String dtmetaType;
    
    private String crtDate;
    
    private String crtAccountId;
    
    private String englishName;
    
    private String dtmetaTypeLength;
    
    
    
    public String getDatametaId() {
        return datametaId;
    }

    public void setDatametaId(String datametaId) {
        this.datametaId = datametaId;
    }
    
    public String getDtmetaCate() {
        return dtmetaCate;
    }

    public void setDtmetaCate(String dtmetaCate) {
        this.dtmetaCate = dtmetaCate;
    }
    
    public String getDtmetaDesc() {
        return dtmetaDesc;
    }

    public void setDtmetaDesc(String dtmetaDesc) {
        this.dtmetaDesc = dtmetaDesc;
    }
    
    public String getDtmetaDomain() {
        return dtmetaDomain;
    }

    public void setDtmetaDomain(String dtmetaDomain) {
        this.dtmetaDomain = dtmetaDomain;
    }
    
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
    
    public String getDtmetaName() {
        return dtmetaName;
    }

    public void setDtmetaName(String dtmetaName) {
        this.dtmetaName = dtmetaName;
    }
    
    public String getDtmetaType() {
        return dtmetaType;
    }

    public void setDtmetaType(String dtmetaType) {
        this.dtmetaType = dtmetaType;
    }
    
    public String getCrtDate() {
        return crtDate;
    }

    public void setCrtDate(String crtDate) {
        this.crtDate = crtDate;
    }
    
    public String getCrtAccountId() {
        return crtAccountId;
    }

    public void setCrtAccountId(String crtAccountId) {
        this.crtAccountId = crtAccountId;
    }
    
    public String getEnglishName() {
        return englishName;
    }

    public void setEnglishName(String englishName) {
        this.englishName = englishName;
    }
    
    public String getDtmetaTypeLength() {
        return dtmetaTypeLength;
    }

    public void setDtmetaTypeLength(String dtmetaTypeLength) {
        this.dtmetaTypeLength = dtmetaTypeLength;
    }
    
        
}