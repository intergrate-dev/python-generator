package com.ccb.portal.datameta.service;

import java.util.List;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.portal.datameta.vo.DatametaVo;
import ;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;

public interface DatametaService1 {
    
    /**
     * 插入xx
     *
     * @param jsonString
     * @return
     */
    public String createDatameta(String jsonString) throws Exception;
    
    /**
     * 分页查询xx
     *
     * @param jsonString
     * @return
     */
    public String getList(String jsonString) throws Exception;

    /**
     * 查询xx详情
     *
     * @param jsonString
     * @return
     */
    public String getDetail(String jsonString) throws Exception;
    
    public DatametaDo getDatametaById(String id) throws Exception;

    /**
     * 更新xx
     *
     * @param jsonString
     * @return
     */
    public String update(String jsonString) throws Exception;

    /**
     * 发布xx
     *
     * @param jsonString
     * @return
     */
    public String publish(String jsonString) throws Exception;

    /**
     * 注销xx
     *
     * @param jsonString
     * @return
     */
    public String revocate(String jsonString) throws Exception;

    /**
     * 删除xx
     *
     * @param jsonString
     * @return
     */
    public String delete(String jsonString) throws Exception;

}elete(String jsonString) throws Exception;

}