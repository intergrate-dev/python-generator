package com.ccb.portal.datameta.service.impl;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import com.alibaba.fastjson.JSONObject;
import com.ccb.portal.datameta.dos.DatametaDo;
import com.ccb.portal.datameta.vo.DatametaVo;
import com.ccb.portal.datameta.service.DatametaService;
import com.ccb.portal.common.entity.ReqTxnCommCom;
import com.ccb.portal.common.entity.ResTxnCommCom;
import com.ccb.portal.common.validation.ValidateUtil;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.pub.ErrorCodeEnum;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("portal.DatametaService")
public class DatametaServiceImpl implements DatametaService {
    private Logger log = LoggerFactory.getLogger(DatametaServiceImpl.class);
    
    @Autowired
    DatametaService datametaService;
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String createDatameta(String jsonString) throws Exception {
        DatametaDo datametaDo = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            datametaDo = JSONObject.parseObject(body.getString("datameta"), DatametaDo.class);
            Map doMap = JSONObject.parseObject(body.getString("datameta"), HashMap.class);
            // TODO, add items required
            List<String> items = new ArrayList<>();
            items.add("");
            // ValidateUtil.validParams(doMap, items);
            // TODO set datametaId, 前端自己生成，还是后端提供接口生成
            // TODO set time
            datametaDo.insertDatameta();
            
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "创建成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("create datameta occure exception, datametaId: {}, error: {}", datametaDo.getDatametaId(), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "创建xx失败");
        }
    }
    
    @Override
    public String getList(String jsonString) throws Exception {
        try{
            this.checkReqParams(jsonString);
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            this.checkPage(common);
            ResTxnCommCom rtc = new ResTxnCommCom();
            rtc.setStsTraceId(common.getTStsTraceId());
            rtc.setTCurrTotalPage(common.getTPageJump());
            rtc.setTCurrTotalRec(common.getTRecInPage());
            Map<String, Object> map = new HashMap();
            Integer pageNo = Integer.valueOf(StringUtils.defaultIfEmpty(common.getTPageJump(), "1"))
            Integer pageSize = Integer.valueOf(StringUtils.defaultIfEmpty(common.getTRecInPage(), "10"))
            map.put("tPageJump", (pageNo - 1) * pageSize);
            map.put("tRecInPage", pageSize);
            DatametaDo datametaDo = new DatametaDo();
            int total = datametaDo.queryDataCount(map);
            List<DatametaVo> dataList = datametaDo.queryDataList(map);

            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            this.setPage(common, rtc, total);
            return getObject(rtc, dataList);
        } catch(Exception e) {
            log.info("getList datameta occure exception, error: {}", e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询xx列表失败");
        }
    }

    @Override
    public String getDetail(String jsonString) throws Exception {
        String datametaId = null;
        try{
            this.checkReqParams(jsonString);
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            datametaId = body.getString("datametaId");
            // ValidateUtil.checkIsValid("datametaId", datametaId);

            Map<String, Object> map = new HashMap<>();
            map.put("datametaId", datametaId);
            com.ccb.portal.datameta.vo.DatametaVo detail = new DatametaDo().queryDetail(map);
            return getObject(jsonCommon, detail);
        } catch(Exception e) {
            log.info("getDetail datameta occure exception, datametaId: {}, error: {}", datametaDo.getDatametaId(), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询xx详情失败");
        }
    }
    
    public DatametaDo getDatametaById(String id) throws Exception {
        return new DatametaDo().findById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String update(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            //datametaDo = JSONObject.parseObject(body.getString("datameta"), DatametaDo.class);
            doMap = JSONObject.parseObject(body.getString("datameta"), HashMap.class);
            // TODO, add items required
            List<String> items = new ArrayList<>();
            items.add("");
            // ValidateUtil.validParams(doMap, items);
            // TODO set time
            new DatametaDo.updateDatameta(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "修改成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("update datameta occure exception, datametaId: {}, error: {}", doMap.get("datametaId"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "修改xx信息失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String publish(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("datameta"), HashMap.class);
            doMap.put("state", "1");
            new DatametaDo().updateDatameta(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "发布成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("publish datameta occure exception, datametaId: {}, error: {}", doMap.get("datametaId"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "发布xx失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String revocate(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            Map doMap = JSONObject.parseObject(body.getString("datameta"), HashMap.class);
            doMap.put("state", "0");
            new DatametaDo().updateDatameta(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "注销成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("revocate datameta occure exception, datametaId: {}, error: {}", doMap.get("datametaId"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "注销xx失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String delete(String jsonString) throws Exception {
        return null;
    }

} {
        return null;
    }

}