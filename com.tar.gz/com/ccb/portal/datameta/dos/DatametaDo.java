package com.ccb.portal.datameta.dos.DatametaDo;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.portal.datameta.vo.DatametaVo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.pub.ErrorCodeEnum;

public class DatametaDo extends BaseMDo<DatametaDo>{
    private Logger log = LoggerFactory.getLogger(DatametaDo.class);
    
    private String datametaId;
    
    private String dtmetaCate;
    
    private String dtmetaDesc;
    
    private String dtmetaDomain;
    
    private String state;
    
    private String remark;
    
    private String dtmetaName;
    
    private String dtmetaType;
    
    private String crtDate;
    
    private String crtAccountId;
    
    private String englishName;
    
    private String dtmetaTypeLength;
    
    
    public String getDatametaId() {
        return this.datametaId;
    }

    public void setDatametaId(String datametaId) {
        this.datametaId = datametaId;
    }
    
    public String getDtmetaCate() {
        return dtmetaCate;
    }

    public void setDtmetaCate(String dtmetaCate) {
        this.dtmetaCate = dtmetaCate;
    }
    
    public String getDtmetaDesc() {
        return dtmetaDesc;
    }

    public void setDtmetaDesc(String dtmetaDesc) {
        this.dtmetaDesc = dtmetaDesc;
    }
    
    public String getDtmetaDomain() {
        return dtmetaDomain;
    }

    public void setDtmetaDomain(String dtmetaDomain) {
        this.dtmetaDomain = dtmetaDomain;
    }
    
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
    
    public String getDtmetaName() {
        return dtmetaName;
    }

    public void setDtmetaName(String dtmetaName) {
        this.dtmetaName = dtmetaName;
    }
    
    public String getDtmetaType() {
        return dtmetaType;
    }

    public void setDtmetaType(String dtmetaType) {
        this.dtmetaType = dtmetaType;
    }
    
    public String getCrtDate() {
        return crtDate;
    }

    public void setCrtDate(String crtDate) {
        this.crtDate = crtDate;
    }
    
    public String getCrtAccountId() {
        return crtAccountId;
    }

    public void setCrtAccountId(String crtAccountId) {
        this.crtAccountId = crtAccountId;
    }
    
    public String getEnglishName() {
        return englishName;
    }

    public void setEnglishName(String englishName) {
        this.englishName = englishName;
    }
    
    public String getDtmetaTypeLength() {
        return dtmetaTypeLength;
    }

    public void setDtmetaTypeLength(String dtmetaTypeLength) {
        this.dtmetaTypeLength = dtmetaTypeLength;
    }
    

	public int insertDatameta() throws Exception {
        int i = 0;
        try{
            i = _dao.insertBySqlMap_mybatis("portal.datameta.insert", this);
        } catch (Exception e) {
            log.error("insert datameta failure, message: {}", e.getMessage());
            throw new CommonRuntimeException(null, "插入xx数据失败");
        }
        return i;
	}

    public int queryDataCount(Map<String, Object> map) throws Exception {
        int count = 0;
        try{
            count = (Integer) _dao.findObjectBySqlMap_mybatis("portal.datameta.queryCount", map);
        } catch (Exception ex) {
            log.error("queryDataCount datameta failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(null, "查询xx数据失败");
        }
        return count;
	}

    public List<DatametaVo> queryDataList(Map<String, Object> map) throws Exception {
        List<DatametaVo> list = null;
        try{
            list = (List<DatametaVo>) _dao.findListBySqlMap_mybatis("portal.datameta.queryListByMap", map);
        } catch (Exception ex) {
            log.error("queryDataList datameta failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(null, "查询xx数据失败");
        }
        return list;
	}

    public DatametaVo queryDetail(Map<String, Object> map) throws Exception {
        List<DatametaVo> list = null;
        try{
            list = (List<DatametaVo>) _dao.findListBySqlMap_mybatis("portal.datameta.queryListByMap", map);
        } catch (Exception ex) {
            log.error("queryDetail datameta failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(null, "查询xx数据失败");
        }
        return list == null || list.size() == 0 ? null : list.get(0);
	}

    public DatametaDo findById(String id) throws Exception {
        List<DatametaDo> list = null;
        try{
            Map map = new HashMap();
            map.put("datametaId", id);
            list = (List<DatametaDo>) _dao.findListBySqlMap_mybatis("portal.datameta.findById", map);
        } catch (Exception ex) {
            log.error("findById datameta failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(null, "查询xx数据失败");
        }
        return list == null || list.size() == 0 ? null : list.get(0);
	}

    public void updateDatameta(Map<String, String> map) throws Exception {
        try{
            _dao.updateBySqlMap_mybatis("portal.datameta.updateByMap", map);
        } catch (Exception ex) {
            log.error("updateDatameta datameta failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(null, "更新xx数据失败");
        }
    }
        
}