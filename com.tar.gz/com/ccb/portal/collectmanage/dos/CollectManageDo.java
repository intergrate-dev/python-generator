package com.ccb.portal.collectmanage.dos.CollectManageDo;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.portal.collectmanage.vo.CollectManageVo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.pub.ErrorCodeEnum;

public class CollectManageDo extends BaseMDo<CollectManageDo>{
    private Logger log = LoggerFactory.getLogger(CollectManageDo.class);
    
    private String exchangeMetadataId;
    
    private String resourceCode;
    
    private String resourceName;
    
    private String resourceOwner;
    
    private String resourceSubscriber;
    
    private String exchangeType;
    
    private String effectiveState;
    
    private String exchangeState;
    
    private String createTime;
    
    
    public String getExchangeMetadataId() {
        return this.exchangeMetadataId;
    }

    public void setExchangeMetadataId(String exchangeMetadataId) {
        this.exchangeMetadataId = exchangeMetadataId;
    }
    
    public String getResourceCode() {
        return resourceCode;
    }

    public void setResourceCode(String resourceCode) {
        this.resourceCode = resourceCode;
    }
    
    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }
    
    public String getResourceOwner() {
        return resourceOwner;
    }

    public void setResourceOwner(String resourceOwner) {
        this.resourceOwner = resourceOwner;
    }
    
    public String getResourceSubscriber() {
        return resourceSubscriber;
    }

    public void setResourceSubscriber(String resourceSubscriber) {
        this.resourceSubscriber = resourceSubscriber;
    }
    
    public String getExchangeType() {
        return exchangeType;
    }

    public void setExchangeType(String exchangeType) {
        this.exchangeType = exchangeType;
    }
    
    public String getEffectiveState() {
        return effectiveState;
    }

    public void setEffectiveState(String effectiveState) {
        this.effectiveState = effectiveState;
    }
    
    public String getExchangeState() {
        return exchangeState;
    }

    public void setExchangeState(String exchangeState) {
        this.exchangeState = exchangeState;
    }
    
    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
    

	public int insertCollectManage() throws Exception {
        int i = 0;
        try{
            i = _dao.insertBySqlMap_mybatis("portal.collectManage.insert", this);
        } catch (Exception e) {
            log.error("insert collectManage failure, message: {}", e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "插入归集管理数据失败");
        }
        return i;
	}

    public int queryDataCount(Map<String, Object> map) throws Exception {
        int count = 0;
        try{
            count = (Integer) _dao.findObjectBySqlMap_mybatis("portal.collectManage.queryCount", map);
        } catch (Exception ex) {
            log.error("queryDataCount collectManage failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询归集管理数据失败");
        }
        return count;
	}

    public List<CollectManageVo> queryDataList(Map<String, Object> map) throws Exception {
        List<CollectManageVo> list = null;
        try{
            list = (List<CollectManageVo>) _dao.findListBySqlMap_mybatis("portal.collectManage.queryListByMap", map);
        } catch (Exception ex) {
            log.error("queryDataList collectManage failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询归集管理数据失败");
        }
        return list;
	}

    public CollectManageVo queryDetail(Map<String, Object> map) throws Exception {
        List<CollectManageVo> list = null;
        try{
            list = (List<CollectManageVo>) _dao.findListBySqlMap_mybatis("portal.collectManage.queryListByMap", map);
        } catch (Exception ex) {
            log.error("queryDetail collectManage failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询归集管理数据失败");
        }
        return list == null || list.size() == 0 ? null : list.get(0);
	}

    public CollectManageDo findById(String id) throws Exception {
        List<CollectManageDo> list = null;
        try{
            Map map = new HashMap();
            map.put("exchangeMetadataId", id);
            list = (List<CollectManageDo>) _dao.findListBySqlMap_mybatis("portal.collectManage.findById", map);
        } catch (Exception ex) {
            log.error("findById collectManage failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询归集管理数据失败");
        }
        return list == null || list.size() == 0 ? null : list.get(0);
	}

    public void updateCollectManage(Map<String, String> map) throws Exception {
        try{
            _dao.updateBySqlMap_mybatis("portal.collectManage.updateByMap", map);
        } catch (Exception ex) {
            log.error("updateCollectManage collectManage failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "更新归集管理数据失败");
        }
    }
        
}