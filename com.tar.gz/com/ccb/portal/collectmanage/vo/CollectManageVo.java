package com.ccb.portal.collectmanage.vo.CollectManageVo;

import java.util.List;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;

public class CollectManageVo {
    private Logger log = LoggerFactory.getLogger(CollectManageVo.class);
    
    
    private String exchangeMetadataId;
    
    private String resourceCode;
    
    private String resourceName;
    
    private String resourceOwner;
    
    private String resourceSubscriber;
    
    private String exchangeType;
    
    private String effectiveState;
    
    private String exchangeState;
    
    private String createTime;
    
    
    
    public String getExchangeMetadataId() {
        return exchangeMetadataId;
    }

    public void setExchangeMetadataId(String exchangeMetadataId) {
        this.exchangeMetadataId = exchangeMetadataId;
    }
    
    public String getResourceCode() {
        return resourceCode;
    }

    public void setResourceCode(String resourceCode) {
        this.resourceCode = resourceCode;
    }
    
    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }
    
    public String getResourceOwner() {
        return resourceOwner;
    }

    public void setResourceOwner(String resourceOwner) {
        this.resourceOwner = resourceOwner;
    }
    
    public String getResourceSubscriber() {
        return resourceSubscriber;
    }

    public void setResourceSubscriber(String resourceSubscriber) {
        this.resourceSubscriber = resourceSubscriber;
    }
    
    public String getExchangeType() {
        return exchangeType;
    }

    public void setExchangeType(String exchangeType) {
        this.exchangeType = exchangeType;
    }
    
    public String getEffectiveState() {
        return effectiveState;
    }

    public void setEffectiveState(String effectiveState) {
        this.effectiveState = effectiveState;
    }
    
    public String getExchangeState() {
        return exchangeState;
    }

    public void setExchangeState(String exchangeState) {
        this.exchangeState = exchangeState;
    }
    
    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
    
        
}