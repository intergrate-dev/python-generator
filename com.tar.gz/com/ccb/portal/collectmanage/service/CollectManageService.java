package com.ccb.portal.collectmanage.service;

import java.util.List;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.portal.collectmanage.vo.CollectManageVo;
import ;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;

public interface CollectManageService {
    
    /**
     * 插入归集管理
     *
     * @param jsonString
     * @return
     */
    public String createCollectManage(String jsonString) throws Exception;
    
    /**
     * 分页查询归集管理
     *
     * @param jsonString
     * @return
     */
    public String getList(String jsonString) throws Exception;

    /**
     * 查询归集管理详情
     *
     * @param jsonString
     * @return
     */
    public String getDetail(String jsonString) throws Exception;
    
    public CollectManageDo getCollectManageById(String id) throws Exception;

    /**
     * 更新归集管理
     *
     * @param jsonString
     * @return
     */
    public String update(String jsonString) throws Exception;

    /**
     * 发布归集管理
     *
     * @param jsonString
     * @return
     */
    public String publish(String jsonString) throws Exception;

    /**
     * 注销归集管理
     *
     * @param jsonString
     * @return
     */
    public String revocate(String jsonString) throws Exception;

    /**
     * 删除归集管理
     *
     * @param jsonString
     * @return
     */
    public String delete(String jsonString) throws Exception;

}