package com.ccb.portal.collectmanage.service.impl;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import com.alibaba.fastjson.JSONObject;
import com.ccb.portal.collectmanage.dos.CollectManageDo;
import com.ccb.portal.collectmanage.vo.CollectManageVo;
import com.ccb.portal.collectmanage.service.CollectManageService;
import com.ccb.portal.common.entity.ReqTxnCommCom;
import com.ccb.portal.common.entity.ResTxnCommCom;
import com.ccb.portal.common.validation.ValidateUtil;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.pub.ErrorCodeEnum;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("portal.CollectManageService")
public class CollectManageServiceImpl implements CollectManageService {
    private Logger log = LoggerFactory.getLogger(CollectManageServiceImpl.class);
    
    @Autowired
    CollectManageService collectManageService;
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String createCollectManage(String jsonString) throws Exception {
        CollectManageDo collectManageDo = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            collectManageDo = JSONObject.parseObject(body.getString("collectManage"), CollectManageDo.class);
            Map doMap = JSONObject.parseObject(body.getString("collectManage"), HashMap.class);
            // TODO, add items required
            List<String> items = new ArrayList<>();
            items.add("");
            // ValidateUtil.validParams(doMap, items);
            // TODO set exchangeMetadataId, 前端自己生成，还是后端提供接口生成
            // TODO set time
            collectManageDo.insertCollectManage();
            
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "创建成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("create collectManage occure exception, exchangeMetadataId: {}, error: {}", collectManageDo.getExchangeMetadataId(), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "创建归集管理失败");
        }
    }
    
    @Override
    public String getList(String jsonString) throws Exception {
        try{
            //this.checkReqParams(jsonString);
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            //this.checkPage(common);
            ResTxnCommCom rtc = new ResTxnCommCom();
            rtc.setStsTraceId(common.getTStsTraceId());
            rtc.setTCurrTotalPage(common.getTPageJump());
            rtc.setTCurrTotalRec(common.getTRecInPage());
            Map<String, Object> map = new HashMap();
            Integer pageNo = Integer.valueOf(StringUtils.defaultIfEmpty(common.getTPageJump(), "1"));
            Integer pageSize = Integer.valueOf(StringUtils.defaultIfEmpty(common.getTRecInPage(), "10"));
            map.put("tPageJump", (pageNo - 1) * pageSize);
            map.put("tRecInPage", pageSize);
            CollectManageDo collectManageDo = new CollectManageDo();
            int total = collectManageDo.queryDataCount(map);
            List<CollectManageVo> dataList = collectManageDo.queryDataList(map);

            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            this.setPage(common, rtc, total);
            return getObject(rtc, dataList);
        } catch(Exception e) {
            log.info("getList collectManage occure exception, error: {}", e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询归集管理列表失败");
        }
    }

    @Override
    public String getDetail(String jsonString) throws Exception {
        String exchangeMetadataId = null;
        try{
            //this.checkReqParams(jsonString);
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            exchangeMetadataId = body.getString("exchangeMetadataId");
            // ValidateUtil.checkIsValid("exchangeMetadataId", exchangeMetadataId);

            Map<String, Object> map = new HashMap<>();
            map.put("exchangeMetadataId", exchangeMetadataId);
            com.ccb.portal.collectmanage.vo.CollectManageVo detail = new CollectManageDo().queryDetail(map);
            return getObject(jsonCommon, detail);
        } catch(Exception e) {
            log.info("getDetail collectManage occure exception, exchangeMetadataId: {}, error: {}", exchangeMetadataId, e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询归集管理详情失败");
        }
    }
    
    public CollectManageDo getCollectManageById(String id) throws Exception {
        return new CollectManageDo().findById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String update(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            //collectManageDo = JSONObject.parseObject(body.getString("collectManage"), CollectManageDo.class);
            doMap = JSONObject.parseObject(body.getString("collectManage"), HashMap.class);
            // TODO, add items required
            List<String> items = new ArrayList<>();
            items.add("");
            // ValidateUtil.validParams(doMap, items);
            // TODO set time
            new CollectManageDo().updateCollectManage(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "修改成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("update collectManage occure exception, exchangeMetadataId: {}, error: {}", doMap.get("exchangeMetadataId"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "修改归集管理信息失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String publish(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("collectManage"), HashMap.class);
            doMap.put("state", "1");
            new CollectManageDo().updateCollectManage(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "发布成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("publish collectManage occure exception, exchangeMetadataId: {}, error: {}", doMap.get("exchangeMetadataId"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "发布归集管理失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String revocate(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("collectManage"), HashMap.class);
            doMap.put("state", "0");
            new CollectManageDo().updateCollectManage(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "注销成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("revocate collectManage occure exception, exchangeMetadataId: {}, error: {}", doMap.get("exchangeMetadataId"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "注销归集管理失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String delete(String jsonString) throws Exception {
        return null;
    }

    private ReqTxnCommCom getReqTxnComm(string jsonString) {
        JSONObject request = JSONObject.parseObject(jsonString);
        return JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_COMM_COM), ReqTxnCommCom.class);
    }

    private String getObject(Object common, Object body) {
        JSONObject result = new JSONObject();
        result.put(ReqTxnCommCom.TXN_COMM_COM, common);
        result.put(ReqTxnCommCom.TXN_BODY_COM, body);
        return result.toString();
    }

    private void setPage(ReqTxnCommCom common, ResTxnCommCom rtc, Integer total) {
        Integer pageSize = Integer.parseInt(common.getTRecInPage());
        rtc.setTotalPage(String.valueof((total + pageSize - 1)/ pageSize));
        rtc.setTotalRec(String.valueOf(total));
    }

}
















