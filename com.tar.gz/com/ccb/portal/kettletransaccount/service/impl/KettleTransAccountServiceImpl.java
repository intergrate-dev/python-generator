package com.ccb.portal.kettletransaccount.service.impl;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import com.alibaba.fastjson.JSONObject;
import com.ccb.portal.kettletransaccount.dos.KettleTransAccountDo;
import com.ccb.portal.kettletransaccount.vo.KettleTransAccountVo;
import com.ccb.portal.kettletransaccount.service.KettleTransAccountService;
import com.ccb.portal.common.entity.ReqTxnCommCom;
import com.ccb.portal.common.entity.ResTxnCommCom;
import com.ccb.portal.common.validation.ValidateUtil;
import com.ccb.esp.cloud.matter.data.dos.BaseMDo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.pub.ErrorCodeEnum;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("portal.KettleTransAccountService")
public class KettleTransAccountServiceImpl implements KettleTransAccountService {
    private Logger log = LoggerFactory.getLogger(KettleTransAccountServiceImpl.class);
    
    @Autowired
    KettleTransAccountService kettleTransAccountService;
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String createKettleTransAccount(String jsonString) throws Exception {
        KettleTransAccountDo kettleTransAccountDo = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            kettleTransAccountDo = JSONObject.parseObject(body.getString("kettleTransAccount"), KettleTransAccountDo.class);
            Map doMap = JSONObject.parseObject(body.getString("kettleTransAccount"), HashMap.class);
            // TODO, add items required
            List<String> items = new ArrayList<>();
            items.add("");
            // ValidateUtil.validParams(doMap, items);
            // TODO set accountID, 前端自己生成，还是后端提供接口生成
            // TODO set time
            kettleTransAccountDo.insertKettleTransAccount();
            
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "创建成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("create kettleTransAccount occure exception, accountID: {}, error: {}", kettleTransAccountDo.getAccountID(), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "创建xx失败");
        }
    }
    
    @Override
    public String getList(String jsonString) throws Exception {
        try{
            this.checkReqParams(jsonString);
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            this.checkPage(common);
            ResTxnCommCom rtc = new ResTxnCommCom();
            rtc.setStsTraceId(common.getTStsTraceId());
            rtc.setTCurrTotalPage(common.getTPageJump());
            rtc.setTCurrTotalRec(common.getTRecInPage());
            Map<String, Object> map = new HashMap();
            Integer pageNo = Integer.valueOf(StringUtils.defaultIfEmpty(common.getTPageJump(), "1"))
            Integer pageSize = Integer.valueOf(StringUtils.defaultIfEmpty(common.getTRecInPage(), "10"))
            map.put("tPageJump", (pageNo - 1) * pageSize);
            map.put("tRecInPage", pageSize);
            KettleTransAccountDo kettleTransAccountDo = new KettleTransAccountDo();
            int total = kettleTransAccountDo.queryDataCount(map);
            List<KettleTransAccountVo> dataList = kettleTransAccountDo.queryDataList(map);

            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            this.setPage(common, rtc, total);
            return getObject(rtc, dataList);
        } catch(Exception e) {
            log.info("getList kettleTransAccount occure exception, error: {}", e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询xx列表失败");
        }
    }

    @Override
    public String getDetail(String jsonString) throws Exception {
        String accountID = null;
        try{
            this.checkReqParams(jsonString);
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            accountID = body.getString("accountID");
            // ValidateUtil.checkIsValid("accountID", accountID);

            Map<String, Object> map = new HashMap<>();
            map.put("accountID", accountID);
            com.ccb.portal.kettletransaccount.vo.KettleTransAccountVo detail = new KettleTransAccountDo().queryDetail(map);
            return getObject(jsonCommon, detail);
        } catch(Exception e) {
            log.info("getDetail kettleTransAccount occure exception, accountID: {}, error: {}", kettleTransAccountDo.getAccountID(), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询xx详情失败");
        }
    }
    
    public KettleTransAccountDo getKettleTransAccountById(String id) throws Exception {
        return new KettleTransAccountDo().findById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String update(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            //kettleTransAccountDo = JSONObject.parseObject(body.getString("kettleTransAccount"), KettleTransAccountDo.class);
            doMap = JSONObject.parseObject(body.getString("kettleTransAccount"), HashMap.class);
            // TODO, add items required
            List<String> items = new ArrayList<>();
            items.add("");
            // ValidateUtil.validParams(doMap, items);
            // TODO set time
            new KettleTransAccountDo.updateKettleTransAccount(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "修改成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("update kettleTransAccount occure exception, accountID: {}, error: {}", doMap.get("accountID"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "修改xx信息失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String publish(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("kettleTransAccount"), HashMap.class);
            doMap.put("state", "1");
            new KettleTransAccountDo().updateKettleTransAccount(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "发布成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("publish kettleTransAccount occure exception, accountID: {}, error: {}", doMap.get("accountID"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "发布xx失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String revocate(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString(ReqTxnCommCom.TXN_BODY_COM));
            ReqTxnCommCom common = getReqTxnComm(jsonString);
            Map doMap = JSONObject.parseObject(body.getString("kettleTransAccount"), HashMap.class);
            doMap.put("state", "0");
            new KettleTransAccountDo().updateKettleTransAccount(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.getTStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "注销成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("revocate kettleTransAccount occure exception, accountID: {}, error: {}", doMap.get("accountID"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "注销xx失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String delete(String jsonString) throws Exception {
        return null;
    }

}