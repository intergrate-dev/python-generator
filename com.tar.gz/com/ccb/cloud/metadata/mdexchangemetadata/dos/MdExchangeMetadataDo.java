package com.ccb.cloud.metadata.mdexchangemetadata.dos;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.ccb.cloud.data.dos.BaseDos;
import com.ccb.cloud.metadata.mdexchangemetadata.vo.MdExchangeMetadataVo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.cloud.basic.common.consts.ErrorCodeEnum;

public class MdExchangeMetadataDo extends BaseDos {
    private Logger log = LoggerFactory.getLogger(MdExchangeMetadataDo.class);

    /** 
 *资源编码  
 */ 
private String resourceCode;

/** 
 *资源名称  
 */ 
private String resourceName;

/** 
 *资源归属方  
 */ 
private String resourceOwner;

/** 
 *资源订阅方  
 */ 
private String resourceSubscriber;

/** 
 *订阅类型 1-文件，2-数据库，3-API，4-数据库 
 */ 
private String subscribeType;

/** 
 *交换来源 数据提供方逻辑节点编码 
 */ 
private String exchangeSource;

/** 
 *交换目的 数据订阅方逻辑节点编码 
 */ 
private String exchangeTarget;

/** 
 *交换成因 形成交换元数据的原因，1-归集，2-订阅 
 */ 
private String exchangeReason;

/** 
 *交换场景 1-数据库-数据库，2-数据库-区块链 
 */ 
private String exchangeScene;

/** 
 *增量同步策略 1-批次号，2-主键，3-时间戳 
 */ 
private String incrementalSynchronizationStrategy;

/** 
 *交换状态 1-启用，2-停用，3-废弃 
 */ 
private String exchangeState;

/** 
 *有效状态 1-有效，2-失效 
 */ 
private String effectiveState;

/** 
 *增量标识 1-是，2-否 
 */ 
private String incrementalFlag;

/** 
 *初始化标识 1-是，2-否 
 */ 
private String initializeFlag;

/** 
 *审核通过时间  
 */ 
private Date auditPassTime;

/** 
 *创建人  
 */ 
private String createBy;

/** 
 *创建时间  
 */ 
private Date createTime;

/** 
 *更新人  
 */ 
private String updateBy;

/** 
 *更新时间  
 */ 
private Date updateTime;

/** 
 *时间戳  
 */ 
private Date tms;

/** 
 *版本号  
 */ 
private String vno;

/** 
 *DAC校验  
 */ 
private String dacVerf;

/** 
 *租户标识  
 */ 
private String tenant;

/** 
 *渠道类型编码  
 */ 
private String txnIttChnlCgyCode;

/** 
 *渠道编号  
 */ 
private String txnIttChnlId;

/** 
 *预留字段1  
 */ 
private String reserve1;

/** 
 *预留字段2  
 */ 
private String reserve2;

/** 
 *预留字段3  
 */ 
private String reserve3;

      

    
    public String getResourceCode() {
        return resourceCode;
    }

    public void setResourceCode(String resourceCode) {
        this.resourceCode = resourceCode;
    }
    
    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }
    
    public String getResourceOwner() {
        return resourceOwner;
    }

    public void setResourceOwner(String resourceOwner) {
        this.resourceOwner = resourceOwner;
    }
    
    public String getResourceSubscriber() {
        return resourceSubscriber;
    }

    public void setResourceSubscriber(String resourceSubscriber) {
        this.resourceSubscriber = resourceSubscriber;
    }
    
    public String getSubscribeType() {
        return subscribeType;
    }

    public void setSubscribeType(String subscribeType) {
        this.subscribeType = subscribeType;
    }
    
    public String getExchangeSource() {
        return exchangeSource;
    }

    public void setExchangeSource(String exchangeSource) {
        this.exchangeSource = exchangeSource;
    }
    
    public String getExchangeTarget() {
        return exchangeTarget;
    }

    public void setExchangeTarget(String exchangeTarget) {
        this.exchangeTarget = exchangeTarget;
    }
    
    public String getExchangeReason() {
        return exchangeReason;
    }

    public void setExchangeReason(String exchangeReason) {
        this.exchangeReason = exchangeReason;
    }
    
    public String getExchangeScene() {
        return exchangeScene;
    }

    public void setExchangeScene(String exchangeScene) {
        this.exchangeScene = exchangeScene;
    }
    
    public String getIncrementalSynchronizationStrategy() {
        return incrementalSynchronizationStrategy;
    }

    public void setIncrementalSynchronizationStrategy(String incrementalSynchronizationStrategy) {
        this.incrementalSynchronizationStrategy = incrementalSynchronizationStrategy;
    }
    
    public String getExchangeState() {
        return exchangeState;
    }

    public void setExchangeState(String exchangeState) {
        this.exchangeState = exchangeState;
    }
    
    public String getEffectiveState() {
        return effectiveState;
    }

    public void setEffectiveState(String effectiveState) {
        this.effectiveState = effectiveState;
    }
    
    public String getIncrementalFlag() {
        return incrementalFlag;
    }

    public void setIncrementalFlag(String incrementalFlag) {
        this.incrementalFlag = incrementalFlag;
    }
    
    public String getInitializeFlag() {
        return initializeFlag;
    }

    public void setInitializeFlag(String initializeFlag) {
        this.initializeFlag = initializeFlag;
    }
    
    public Date getAuditPassTime() {
        return auditPassTime;
    }

    public void setAuditPassTime(Date auditPassTime) {
        this.auditPassTime = auditPassTime;
    }
    
    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }
    
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }
    
    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
    
    public Date getTms() {
        return tms;
    }

    public void setTms(Date tms) {
        this.tms = tms;
    }
    
    public String getVno() {
        return vno;
    }

    public void setVno(String vno) {
        this.vno = vno;
    }
    
    public String getDacVerf() {
        return dacVerf;
    }

    public void setDacVerf(String dacVerf) {
        this.dacVerf = dacVerf;
    }
    
    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }
    
    public String getTxnIttChnlCgyCode() {
        return txnIttChnlCgyCode;
    }

    public void setTxnIttChnlCgyCode(String txnIttChnlCgyCode) {
        this.txnIttChnlCgyCode = txnIttChnlCgyCode;
    }
    
    public String getTxnIttChnlId() {
        return txnIttChnlId;
    }

    public void setTxnIttChnlId(String txnIttChnlId) {
        this.txnIttChnlId = txnIttChnlId;
    }
    
    public String getReserve1() {
        return reserve1;
    }

    public void setReserve1(String reserve1) {
        this.reserve1 = reserve1;
    }
    
    public String getReserve2() {
        return reserve2;
    }

    public void setReserve2(String reserve2) {
        this.reserve2 = reserve2;
    }
    
    public String getReserve3() {
        return reserve3;
    }

    public void setReserve3(String reserve3) {
        this.reserve3 = reserve3;
    }
      

	public int insertMdExchangeMetadata() throws Exception {
        int i = 0;
        try{
            i = _dao.insertBySqlMap_mybatis("portal.mdExchangeMetadata.insert", this);
        } catch (Exception e) {
            log.error("insert mdExchangeMetadata failure, message: {}", e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "插入交换元数据表数据失败");
        }
        return i;
	}

    public int queryDataCount(Map<String, Object> map) throws Exception {
        int count = 0;
        try{
            count = (Integer) _dao.findObjectBySqlMap_mybatis("portal.mdExchangeMetadata.queryCount", map);
        } catch (Exception ex) {
            log.error("queryDataCount mdExchangeMetadata failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询交换元数据表数据失败");
        }
        return count;
	}

    public List<MdExchangeMetadataVo> queryDataList(Map<String, Object> map) throws Exception {
        List<MdExchangeMetadataVo> list = null;
        try{
            list = (List<MdExchangeMetadataVo>) _dao.findListBySqlMap_mybatis("portal.mdExchangeMetadata.queryListByMap", map);
        } catch (Exception ex) {
            log.error("queryDataList mdExchangeMetadata failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询交换元数据表数据失败");
        }
        return list;
	}

    public MdExchangeMetadataVo queryDetail(Map<String, Object> map) throws Exception {
        List<MdExchangeMetadataVo> list = null;
        try{
            list = (List<MdExchangeMetadataVo>) _dao.findListBySqlMap_mybatis("portal.mdExchangeMetadata.queryListByMap", map);
        } catch (Exception ex) {
            log.error("queryDetail mdExchangeMetadata failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询交换元数据表数据失败");
        }
        return list == null || list.size() == 0 ? null : list.get(0);
	}

    public MdExchangeMetadataDo findById(String id) throws Exception {
        List<MdExchangeMetadataDo> list = null;
        try{
            Map map = new HashMap();
            map.put("excange_metadata_id", id);
            list = (List<MdExchangeMetadataDo>) _dao.findListBySqlMap_mybatis("portal.mdExchangeMetadata.findById", map);
        } catch (Exception ex) {
            log.error("findById mdExchangeMetadata failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询交换元数据表数据失败");
        }
        return list == null || list.size() == 0 ? null : list.get(0);
	}

    public void updateMdExchangeMetadata(Map<String, String> map) throws Exception {
        try{
            _dao.updateBySqlMap_mybatis("portal.mdExchangeMetadata.updateByMap", map);
        } catch (Exception ex) {
            log.error("updateMdExchangeMetadata mdExchangeMetadata failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "更新交换元数据表数据失败");
        }
    }
        
}