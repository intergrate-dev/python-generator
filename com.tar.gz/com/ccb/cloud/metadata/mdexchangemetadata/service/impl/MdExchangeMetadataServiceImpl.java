package com.ccb.cloud.metadata.mdexchangemetadata.service.impl;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import com.alibaba.fastjson.JSONObject;
import com.ccb.cloud.metadata.mdexchangemetadata.dos.MdExchangeMetadataDo;
import com.ccb.cloud.metadata.mdexchangemetadata.vo.MdExchangeMetadataVo;
import com.ccb.cloud.metadata.mdexchangemetadata.service.MdExchangeMetadataService;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.cloud.basic.common.consts.ErrorCodeEnum;
import com.ccb.cloud.basic.common.entity.ComInfoEntity;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("portal.MdExchangeMetadataService")
public class MdExchangeMetadataServiceImpl implements MdExchangeMetadataService {
    private Logger log = LoggerFactory.getLogger(MdExchangeMetadataServiceImpl.class);
    
    @Autowired
    MdExchangeMetadataService mdExchangeMetadataService;
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String createMdExchangeMetadata(String jsonString) throws Exception {
        MdExchangeMetadataDo mdExchangeMetadataDo = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            mdExchangeMetadataDo = JSONObject.parseObject(body.getString("mdExchangeMetadata"), MdExchangeMetadataDo.class);
            Map doMap = JSONObject.parseObject(body.getString("mdExchangeMetadata"), HashMap.class);
            mdExchangeMetadataDo.setExcangeMetadataId(String.valueOf(System.currentTimeMillis()));
            mdExchangeMetadataDo.insertMdExchangeMetadata();
            
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "创建成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("create mdExchangeMetadata occure exception, excangeMetadataId: {}, error: {}", mdExchangeMetadataDo.getExcangeMetadataId(), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "创建交换元数据表失败");
        }
    }
    
    @Override
    public String getList(String jsonString) throws Exception {
        try{
            ComInfoEntity common = getReqTxnComm(jsonString);
            JSONObject rtc = new JSONObject();
            rtc.put("stsTraceId", common.gettStsTraceId());
            rtc.put("tCurrTotalPage", common.gettPageJump());
            rtc.put("tCurrTotalRec", common.gettRecInPage());
            Map<String, Object> map = new HashMap();
            Integer pageNo = common.gettPageJump() == null ? 1 : common.gettPageJump();
            Integer pageSize = common.gettRecInPage() == null ? 10 : common.gettRecInPage();
            map.put("tPageJump", (pageNo - 1) * pageSize);
            map.put("tRecInPage", pageSize);
            MdExchangeMetadataDo mdExchangeMetadataDo = new MdExchangeMetadataDo();
            int total = mdExchangeMetadataDo.queryDataCount(map);
            List<MdExchangeMetadataVo> dataList = mdExchangeMetadataDo.queryDataList(map);

            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            this.setPage(common, rtc, total);
            return getObject(rtc, dataList);
        } catch(Exception e) {
            log.info("getList mdExchangeMetadata occure exception, error: {}", e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询交换元数据表列表失败");
        }
    }

    @Override
    public String getDetail(String jsonString) throws Exception {
        String excangeMetadataId = null;
        try{
            ComInfoEntity common = getReqTxnComm(jsonString);
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            excangeMetadataId = body.getString("excangeMetadataId");

            Map<String, Object> map = new HashMap<>();
            map.put("excange_metadata_id", excangeMetadataId);
            com.ccb.cloud.metadata.mdexchangemetadata.vo.MdExchangeMetadataVo detail = new MdExchangeMetadataDo().queryDetail(map);
            return getObject(jsonCommon, detail);
        } catch(Exception e) {
            log.info("getDetail mdExchangeMetadata occure exception, excangeMetadataId: {}, error: {}", excangeMetadataId, e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询交换元数据表详情失败");
        }
    }
    
    public MdExchangeMetadataDo getMdExchangeMetadataById(String id) throws Exception {
        return new MdExchangeMetadataDo().findById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String update(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("mdExchangeMetadata"), HashMap.class);

            new MdExchangeMetadataDo().updateMdExchangeMetadata(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "修改成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("update mdExchangeMetadata occure exception, excangeMetadataId: {}, error: {}", doMap.get("excange_metadata_id"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "修改交换元数据表信息失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String publish(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("mdExchangeMetadata"), HashMap.class);
            doMap.put("state", "1");
            new MdExchangeMetadataDo().updateMdExchangeMetadata(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "发布成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("publish mdExchangeMetadata occure exception, excangeMetadataId: {}, error: {}", doMap.get("excange_metadata_id"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "发布交换元数据表失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String revocate(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("mdExchangeMetadata"), HashMap.class);
            doMap.put("state", "0");
            new MdExchangeMetadataDo().updateMdExchangeMetadata(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "注销成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("revocate mdExchangeMetadata occure exception, excangeMetadataId: {}, error: {}", doMap.get("excange_metadata_id"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "注销交换元数据表失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String delete(String jsonString) throws Exception {
        return null;
    }

    private ComInfoEntity getReqTxnComm(String jsonString) {
        JSONObject request = JSONObject.parseObject(jsonString);
        return JSONObject.parseObject(request.getString("txnCommCom"), ComInfoEntity.class);
    }

    private String getObject(Object common, Object body) {
        JSONObject result = new JSONObject();
        result.put("txnCommCom", common);
        result.put("txnBodyCom", body);
        return result.toString();
    }

    private void setPage(ComInfoEntity common, JSONObject rtc, Integer total) {
        Integer pageSize = common.gettRecInPage();
        rtc.put("totalPage", String.valueOf((total + pageSize - 1)/ pageSize));
        rtc.put("totalRec", String.valueOf(total));
    }

}
