package com.ccb.cloud.metadata.mdexchangemetadata.service;


import com.ccb.cloud.metadata.mdexchangemetadata.dos.MdExchangeMetadataDo;

public interface MdExchangeMetadataService {
    
    /**
     * 插入交换元数据表
     *
     * @param jsonString
     * @return
     */
    public String createMdExchangeMetadata(String jsonString) throws Exception;
    
    /**
     * 分页查询交换元数据表
     *
     * @param jsonString
     * @return
     */
    public String getList(String jsonString) throws Exception;

    /**
     * 查询交换元数据表详情
     *
     * @param jsonString
     * @return
     */
    public String getDetail(String jsonString) throws Exception;
    
    public MdExchangeMetadataDo getMdExchangeMetadataById(String id) throws Exception;

    /**
     * 更新交换元数据表
     *
     * @param jsonString
     * @return
     */
    public String update(String jsonString) throws Exception;

    /**
     * 发布交换元数据表
     *
     * @param jsonString
     * @return
     */
    public String publish(String jsonString) throws Exception;

    /**
     * 注销交换元数据表
     *
     * @param jsonString
     * @return
     */
    public String revocate(String jsonString) throws Exception;

    /**
     * 删除交换元数据表
     *
     * @param jsonString
     * @return
     */
    public String delete(String jsonString) throws Exception;

}