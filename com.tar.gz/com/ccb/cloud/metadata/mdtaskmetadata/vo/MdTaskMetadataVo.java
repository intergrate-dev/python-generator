package com.ccb.cloud.metadata.mdtaskmetadata.vo;

import java.util.Date;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;

public class MdTaskMetadataVo {
    private Logger log = LoggerFactory.getLogger(MdTaskMetadataVo.class);
    
    /** 
 *任务元数据编码  
 */ 
private String taskMetadataId;

/** 
 *任务元数据描述  
 */ 
private String taskMetadataDesc;

/** 
 *任务元数据类型 1-归集任务，2-初始化任务，3-增量任务 
 */ 
private String taskMetadataType;

/** 
 *交换元数据编码  
 */ 
private String exchangeMetadataId;

/** 
 *资源编码  
 */ 
private String resourceCode;

/** 
 *资源名称  
 */ 
private String resourceName;

/** 
 *资源提供方  
 */ 
private String resourceOwner;

/** 
 *资源订阅方  
 */ 
private String resourceSubscriber;

/** 
 *交换来源 数据提供方逻辑节点编码 
 */ 
private String exchangeSource;

/** 
 *交换目的 数据订阅方逻辑节点编码 
 */ 
private String exchangeTarget;

/** 
 *交换场景 1-数据库-数据库，2-数据库-区块链 
 */ 
private String exchangeScene;

/** 
 *增量同步策略 1-批次号，2-主键，3-时间戳 
 */ 
private String incrementalSynchronizationStrategy;

/** 
 *提供方表名  
 */ 
private String exchangeSourceTablename;

/** 
 *提供方表字段信息  
 */ 
private String exchangeSourceFields;

/** 
 *目的方表名  
 */ 
private String exchangeTargetTablename;

/** 
 *目的方表字段信息  
 */ 
private String exchangeTargetFields;

/** 
 *业务主键名  
 */ 
private String businessPkName;

/** 
 *任务定义编号  
 */ 
private String tskDefId;

/** 
 *任务状态 1-启用，2-停用 
 */ 
private String taskState;

/** 
 *有效状态 1-有效，2-失效 
 */ 
private String effectiveState;

/** 
 *任务执行状态 1-待执行，2-执行中，3-成功，4-失败，9-消息已发送 
 */ 
private String taskExecuteState;

/** 
 *执行周期  
 */ 
private String taskExecuteCycle;

/** 
 *创建人  
 */ 
private String createBy;

/** 
 *创建时间  
 */ 
private Date createTime;

/** 
 *更新人  
 */ 
private String updateBy;

/** 
 *更新时间  
 */ 
private Date updateTime;

/** 
 *时间戳  
 */ 
private Date tms;

/** 
 *版本号  
 */ 
private String vno;

/** 
 *DAC校验  
 */ 
private String dacVerf;

/** 
 *租户标识  
 */ 
private String tenant;

/** 
 *渠道类型编码  
 */ 
private String txnIttChnlCgyCode;

/** 
 *渠道编号  
 */ 
private String txnIttChnlId;

/** 
 *预留字段1  
 */ 
private String reserve1;

/** 
 *预留字段2  
 */ 
private String reserve2;

/** 
 *预留字段3  
 */ 
private String reserve3;

      

    
    public String getTaskMetadataId() {
        return taskMetadataId;
    }

    public void setTaskMetadataId(String taskMetadataId) {
        this.taskMetadataId = taskMetadataId;
    }
    
    public String getTaskMetadataDesc() {
        return taskMetadataDesc;
    }

    public void setTaskMetadataDesc(String taskMetadataDesc) {
        this.taskMetadataDesc = taskMetadataDesc;
    }
    
    public String getTaskMetadataType() {
        return taskMetadataType;
    }

    public void setTaskMetadataType(String taskMetadataType) {
        this.taskMetadataType = taskMetadataType;
    }
    
    public String getExchangeMetadataId() {
        return exchangeMetadataId;
    }

    public void setExchangeMetadataId(String exchangeMetadataId) {
        this.exchangeMetadataId = exchangeMetadataId;
    }
    
    public String getResourceCode() {
        return resourceCode;
    }

    public void setResourceCode(String resourceCode) {
        this.resourceCode = resourceCode;
    }
    
    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }
    
    public String getResourceOwner() {
        return resourceOwner;
    }

    public void setResourceOwner(String resourceOwner) {
        this.resourceOwner = resourceOwner;
    }
    
    public String getResourceSubscriber() {
        return resourceSubscriber;
    }

    public void setResourceSubscriber(String resourceSubscriber) {
        this.resourceSubscriber = resourceSubscriber;
    }
    
    public String getExchangeSource() {
        return exchangeSource;
    }

    public void setExchangeSource(String exchangeSource) {
        this.exchangeSource = exchangeSource;
    }
    
    public String getExchangeTarget() {
        return exchangeTarget;
    }

    public void setExchangeTarget(String exchangeTarget) {
        this.exchangeTarget = exchangeTarget;
    }
    
    public String getExchangeScene() {
        return exchangeScene;
    }

    public void setExchangeScene(String exchangeScene) {
        this.exchangeScene = exchangeScene;
    }
    
    public String getIncrementalSynchronizationStrategy() {
        return incrementalSynchronizationStrategy;
    }

    public void setIncrementalSynchronizationStrategy(String incrementalSynchronizationStrategy) {
        this.incrementalSynchronizationStrategy = incrementalSynchronizationStrategy;
    }
    
    public String getExchangeSourceTablename() {
        return exchangeSourceTablename;
    }

    public void setExchangeSourceTablename(String exchangeSourceTablename) {
        this.exchangeSourceTablename = exchangeSourceTablename;
    }
    
    public String getExchangeSourceFields() {
        return exchangeSourceFields;
    }

    public void setExchangeSourceFields(String exchangeSourceFields) {
        this.exchangeSourceFields = exchangeSourceFields;
    }
    
    public String getExchangeTargetTablename() {
        return exchangeTargetTablename;
    }

    public void setExchangeTargetTablename(String exchangeTargetTablename) {
        this.exchangeTargetTablename = exchangeTargetTablename;
    }
    
    public String getExchangeTargetFields() {
        return exchangeTargetFields;
    }

    public void setExchangeTargetFields(String exchangeTargetFields) {
        this.exchangeTargetFields = exchangeTargetFields;
    }
    
    public String getBusinessPkName() {
        return businessPkName;
    }

    public void setBusinessPkName(String businessPkName) {
        this.businessPkName = businessPkName;
    }
    
    public String getTskDefId() {
        return tskDefId;
    }

    public void setTskDefId(String tskDefId) {
        this.tskDefId = tskDefId;
    }
    
    public String getTaskState() {
        return taskState;
    }

    public void setTaskState(String taskState) {
        this.taskState = taskState;
    }
    
    public String getEffectiveState() {
        return effectiveState;
    }

    public void setEffectiveState(String effectiveState) {
        this.effectiveState = effectiveState;
    }
    
    public String getTaskExecuteState() {
        return taskExecuteState;
    }

    public void setTaskExecuteState(String taskExecuteState) {
        this.taskExecuteState = taskExecuteState;
    }
    
    public String getTaskExecuteCycle() {
        return taskExecuteCycle;
    }

    public void setTaskExecuteCycle(String taskExecuteCycle) {
        this.taskExecuteCycle = taskExecuteCycle;
    }
    
    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }
    
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }
    
    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
    
    public Date getTms() {
        return tms;
    }

    public void setTms(Date tms) {
        this.tms = tms;
    }
    
    public String getVno() {
        return vno;
    }

    public void setVno(String vno) {
        this.vno = vno;
    }
    
    public String getDacVerf() {
        return dacVerf;
    }

    public void setDacVerf(String dacVerf) {
        this.dacVerf = dacVerf;
    }
    
    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }
    
    public String getTxnIttChnlCgyCode() {
        return txnIttChnlCgyCode;
    }

    public void setTxnIttChnlCgyCode(String txnIttChnlCgyCode) {
        this.txnIttChnlCgyCode = txnIttChnlCgyCode;
    }
    
    public String getTxnIttChnlId() {
        return txnIttChnlId;
    }

    public void setTxnIttChnlId(String txnIttChnlId) {
        this.txnIttChnlId = txnIttChnlId;
    }
    
    public String getReserve1() {
        return reserve1;
    }

    public void setReserve1(String reserve1) {
        this.reserve1 = reserve1;
    }
    
    public String getReserve2() {
        return reserve2;
    }

    public void setReserve2(String reserve2) {
        this.reserve2 = reserve2;
    }
    
    public String getReserve3() {
        return reserve3;
    }

    public void setReserve3(String reserve3) {
        this.reserve3 = reserve3;
    }
      
}