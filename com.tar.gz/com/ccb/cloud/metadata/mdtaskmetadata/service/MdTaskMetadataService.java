package com.ccb.cloud.metadata.mdtaskmetadata.service;


import com.ccb.cloud.metadata.mdtaskmetadata.dos.MdTaskMetadataDo;

public interface MdTaskMetadataService {
    
    /**
     * 插入任务元数据表
     *
     * @param jsonString
     * @return
     */
    public String createMdTaskMetadata(String jsonString) throws Exception;
    
    /**
     * 分页查询任务元数据表
     *
     * @param jsonString
     * @return
     */
    public String getList(String jsonString) throws Exception;

    /**
     * 查询任务元数据表详情
     *
     * @param jsonString
     * @return
     */
    public String getDetail(String jsonString) throws Exception;
    
    public MdTaskMetadataDo getMdTaskMetadataById(String id) throws Exception;

    /**
     * 更新任务元数据表
     *
     * @param jsonString
     * @return
     */
    public String update(String jsonString) throws Exception;

    /**
     * 发布任务元数据表
     *
     * @param jsonString
     * @return
     */
    public String publish(String jsonString) throws Exception;

    /**
     * 注销任务元数据表
     *
     * @param jsonString
     * @return
     */
    public String revocate(String jsonString) throws Exception;

    /**
     * 删除任务元数据表
     *
     * @param jsonString
     * @return
     */
    public String delete(String jsonString) throws Exception;

}