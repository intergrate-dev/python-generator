package com.ccb.cloud.metadata.mdtaskmetadata.service.impl;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import com.alibaba.fastjson.JSONObject;
import com.ccb.cloud.metadata.mdtaskmetadata.dos.MdTaskMetadataDo;
import com.ccb.cloud.metadata.mdtaskmetadata.vo.MdTaskMetadataVo;
import com.ccb.cloud.metadata.mdtaskmetadata.service.MdTaskMetadataService;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.cloud.basic.common.consts.ErrorCodeEnum;
import com.ccb.cloud.basic.common.entity.ComInfoEntity;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("portal.MdTaskMetadataService")
public class MdTaskMetadataServiceImpl implements MdTaskMetadataService {
    private Logger log = LoggerFactory.getLogger(MdTaskMetadataServiceImpl.class);
    
    @Autowired
    MdTaskMetadataService mdTaskMetadataService;
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String createMdTaskMetadata(String jsonString) throws Exception {
        MdTaskMetadataDo mdTaskMetadataDo = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            mdTaskMetadataDo = JSONObject.parseObject(body.getString("mdTaskMetadata"), MdTaskMetadataDo.class);
            Map doMap = JSONObject.parseObject(body.getString("mdTaskMetadata"), HashMap.class);
            mdTaskMetadataDo.setTaskMetadataId(String.valueOf(System.currentTimeMillis()));
            mdTaskMetadataDo.insertMdTaskMetadata();
            
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "创建成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("create mdTaskMetadata occure exception, taskMetadataId: {}, error: {}", mdTaskMetadataDo.getTaskMetadataId(), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "创建任务元数据表失败");
        }
    }
    
    @Override
    public String getList(String jsonString) throws Exception {
        try{
            ComInfoEntity common = getReqTxnComm(jsonString);
            JSONObject rtc = new JSONObject();
            rtc.put("stsTraceId", common.gettStsTraceId());
            rtc.put("tCurrTotalPage", common.gettPageJump());
            rtc.put("tCurrTotalRec", common.gettRecInPage());
            Map<String, Object> map = new HashMap();
            Integer pageNo = common.gettPageJump() == null ? 1 : common.gettPageJump();
            Integer pageSize = common.gettRecInPage() == null ? 10 : common.gettRecInPage();
            map.put("tPageJump", (pageNo - 1) * pageSize);
            map.put("tRecInPage", pageSize);
            MdTaskMetadataDo mdTaskMetadataDo = new MdTaskMetadataDo();
            int total = mdTaskMetadataDo.queryDataCount(map);
            List<MdTaskMetadataVo> dataList = mdTaskMetadataDo.queryDataList(map);

            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            this.setPage(common, rtc, total);
            return getObject(rtc, dataList);
        } catch(Exception e) {
            log.info("getList mdTaskMetadata occure exception, error: {}", e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询任务元数据表列表失败");
        }
    }

    @Override
    public String getDetail(String jsonString) throws Exception {
        String taskMetadataId = null;
        try{
            ComInfoEntity common = getReqTxnComm(jsonString);
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            taskMetadataId = body.getString("taskMetadataId");

            Map<String, Object> map = new HashMap<>();
            map.put("task_metadata_id", taskMetadataId);
            com.ccb.cloud.metadata.mdtaskmetadata.vo.MdTaskMetadataVo detail = new MdTaskMetadataDo().queryDetail(map);
            return getObject(jsonCommon, detail);
        } catch(Exception e) {
            log.info("getDetail mdTaskMetadata occure exception, taskMetadataId: {}, error: {}", taskMetadataId, e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询任务元数据表详情失败");
        }
    }
    
    public MdTaskMetadataDo getMdTaskMetadataById(String id) throws Exception {
        return new MdTaskMetadataDo().findById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String update(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("mdTaskMetadata"), HashMap.class);

            new MdTaskMetadataDo().updateMdTaskMetadata(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "修改成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("update mdTaskMetadata occure exception, taskMetadataId: {}, error: {}", doMap.get("task_metadata_id"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "修改任务元数据表信息失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String publish(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("mdTaskMetadata"), HashMap.class);
            doMap.put("state", "1");
            new MdTaskMetadataDo().updateMdTaskMetadata(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "发布成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("publish mdTaskMetadata occure exception, taskMetadataId: {}, error: {}", doMap.get("task_metadata_id"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "发布任务元数据表失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String revocate(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("mdTaskMetadata"), HashMap.class);
            doMap.put("state", "0");
            new MdTaskMetadataDo().updateMdTaskMetadata(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "注销成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("revocate mdTaskMetadata occure exception, taskMetadataId: {}, error: {}", doMap.get("task_metadata_id"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "注销任务元数据表失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String delete(String jsonString) throws Exception {
        return null;
    }

    private ComInfoEntity getReqTxnComm(String jsonString) {
        JSONObject request = JSONObject.parseObject(jsonString);
        return JSONObject.parseObject(request.getString("txnCommCom"), ComInfoEntity.class);
    }

    private String getObject(Object common, Object body) {
        JSONObject result = new JSONObject();
        result.put("txnCommCom", common);
        result.put("txnBodyCom", body);
        return result.toString();
    }

    private void setPage(ComInfoEntity common, JSONObject rtc, Integer total) {
        Integer pageSize = common.gettRecInPage();
        rtc.put("totalPage", String.valueOf((total + pageSize - 1)/ pageSize));
        rtc.put("totalRec", String.valueOf(total));
    }

}
