package com.ccb.cloud.metadata.sysuser.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.validation.constraints.NotNull;

import com.ccb.cloud.metadata.sysuser.service.SysUserService;
import com.ccb.cloud.metadata.sysuser.entity.SysUser;

import com.hwr.common.base.BaseApiService;
import com.hwr.common.base.BaseResponse;
import javax.validation.Valid;
import java.util.List;
import com.ccb.cloud.metadata.sysuser.vo.SysUserVO;
import com.ccb.cloud.metadata.sysuser.dto.SysUserDTO;
import com.ccb.cloud.metadata.sysuser.dto.SysUserPageDTO;


/**
 * @author hwr
 * @version V1.0
 * @Description 控制器
 * @date 2020-11-23
 * @since V1.0
 */
@RestController
@RequestMapping("/wechat/sysUser")
public class SysUserController {

    @Autowired
    private SysUserService sysUserService;

    @Autowired
    private BaseApiService baseApiService;

    /**
	 * @Description: 新增
	 * @since V1.0
	 * @param sysUser
	 */
	@PostMapping(value = "/save" )
    public BaseResponse save(@RequestBody @Valid SysUserDTO sysUser){
		return baseApiService.setResultSuccess(sysUserService.save(sysUser));
	 }

    /**
	 * @Description: 修改
	 * @since V1.0
	 * @param sysUser
	 */
	@PostMapping(value = "/update" )
    public BaseResponse update(@RequestBody @Valid SysUserDTO sysUser){
		return baseApiService.setResultSuccess(sysUserService.update(sysUser));
    }

    /**
	 * @Description: 删除
	 * @since V1.0
	 * @param ids
	 */
	@PostMapping(value = "/delete" )
    public BaseResponse delete(@RequestBody List<Long> ids){
		sysUserService.delete(ids);
		return baseApiService.setResultSuccessMsg("刪除成功");
    }

    /**
	 * @Description: 查询列表
	 * @since V1.0
	 * @param sysUser
	 */
	@GetMapping(value = "/list" )
    public BaseResponse list(@Valid SysUserDTO sysUser){
		List<SysUserVO> list = sysUserService.list(sysUser);
		return baseApiService.setResultSuccess(list);
    }

    /**
	 * @Description: 分页查询列表
	 * @since V1.0
	 * @param sysUser
	 */
	@GetMapping(value = "/page" )
    public BaseResponse page(@Valid SysUserPageDTO sysUser){
		return baseApiService.setResultSuccess(sysUserService.page(sysUser));
    }


    /**
	 * @Description: 通过ID查询
	 * @since V1.0
	 * @param id
	 */
	@GetMapping(value = "/findById" )
    public BaseResponse findById(@NotNull(message = "id不能为空") String id){
        return baseApiService.setResultSuccess(sysUserService.findById(id));
    }

}