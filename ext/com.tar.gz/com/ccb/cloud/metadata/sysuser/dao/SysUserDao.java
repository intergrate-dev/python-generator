package com.ccb.cloud.metadata.sysuser.dao;

import org.springframework.stereotype.Component;

import java.lang.annotation.*;
import com.ccb.cloud.metadata.sysuser.entity.SysUser;
import com.ccb.cloud.metadata.sysuser.vo.SysUserVO;
import com.ccb.cloud.metadata.sysuser.dto.SysUserDTO;
import java.util.List;


 /**
 * @Description 数据库访问类
 * @author admin
 * @version V1.0
 * @since V1.0
 * @date 2020-11-23
 *
 */
@Component
public interface SysUserDao{
    /**
	 * @Description: 新增
	 * @since V1.0
	 * @param sysUser
	 */
     void insert(SysUserDTO sysUser);

     /**
	 * @Description: 批量新增
	 * @since V1.0
	 * @param list
	 */
     void batchInsert(List<SysUserDTO> list);

    /**
	 * @Description: 修改
	 * @since V1.0
	 * @param sysUser
	 */
	 void update(SysUserDTO sysUser);

    /**
	 * @Description: 批量删除
	 * @since V1.0
	 * @param ids
	 */
	 void delete(List<Long> ids);

    /**
	 * @Description: 查询列表
	 * @since V1.0
	 * @param sysUser
	 */
	 List<SysUserVO> list(SysUserDTO sysUser);


    /**
	 * @Description: 通过ID查询
	 * @since V1.0
	 * @param id
	 */
	 SysUserVO findById(String id);
}
