package com.ccb.cloud.metadata.sysuser.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.github.pagehelper.PageHelper;

import com.hwr.common.base.PageData;
import com.ccb.cloud.metadata.sysuser.dao.SysUserDao;
import com.ccb.cloud.metadata.sysuser.entity.SysUser;
import com.ccb.cloud.metadata.sysuser.service.SysUserService;
import com.ccb.cloud.metadata.sysuser.vo.SysUserVO;
import com.ccb.cloud.metadata.sysuser.dto.SysUserDTO;
import com.ccb.cloud.metadata.sysuser.dto.SysUserPageDTO;

import java.util.List;

/**
 * @author hwr
 * @version V1.0
 * @Description 业务类
 * @date 2020-11-23
 * @since V1.0
 */
@Service
public class SysUserServiceImpl implements SysUserService {

    @Autowired
    private SysUserDao sysUserDao;

    /**
	 * @Description: 新增
	 * @since V1.0
	 * @param sysUser
	 */
	public SysUserDTO save(SysUserDTO sysUser) {
        sysUserDao.insert(sysUser);
		return sysUser;
	}

    /**
	 * @Description: 修改
	 * @since V1.0
	 * @param sysUser
	 */
	public SysUserDTO update(SysUserDTO sysUser) {
        sysUserDao.update(sysUser);
		return sysUser;
	}

    /**
	 * @Description: 批量删除
	 * @since V1.0
	 * @param ids
	 */
	public void delete(List<Long> ids) {
        sysUserDao.delete(ids);
	}

    /**
	 * @Description: 查询列表
	 * @since V1.0
	 * @param sysUser
	 */
	public List<SysUserVO> list(SysUserDTO sysUser) {
        return sysUserDao.list(sysUser);
	}

    /**
	 * @Description: 分页查询列表
	 * @since V1.0
	 * @param sysUser
	 */
	public PageData<SysUserVO> page(SysUserPageDTO sysUser) {
            PageData<SysUserVO> pageData = new PageData<>(sysUser.getPageNo(), sysUser.getLimit());
            PageHelper.startPage(pageData.getPageNo(), pageData.getLimit());
            List<SysUserVO> list = sysUserDao.list(sysUser);
            pageData.setData(list);
            return pageData;
	}

    /**
	 * @Description: 通过ID查询
	 * @since V1.0
	 * @param id
	 */
	public SysUserVO findById(String id) {
            return sysUserDao.findById(id);
	}

}