package com.ccb.cloud.metadata.sysuser.service;

import com.ccb.cloud.metadata.sysuser.entity.SysUser;
import com.ccb.cloud.metadata.sysuser.vo.SysUserVO;
import com.ccb.cloud.metadata.sysuser.dto.SysUserDTO;
import com.ccb.cloud.metadata.sysuser.dto.SysUserPageDTO;
import com.hwr.common.base.PageData;

import java.util.List;

/**
 * @author hwr
 * @version V1.0
 * @Description 业务类
 * @date 2020-11-23
 * @since V1.0
 */
public interface SysUserService {

    /**
	 * @Description: 新增
	 * @since V1.0
	 * @param sysUser
	 */
     SysUserDTO save(SysUserDTO sysUser);

    /**
	 * @Description: 修改
	 * @since V1.0
	 * @param sysUser
	 */
	 SysUserDTO update(SysUserDTO sysUser);

    /**
	 * @Description: 批量删除
	 * @since V1.0
	 * @param id
	 */
	 void delete(List<Long> id);

    /**
	 * @Description: 查询列表
	 * @since V1.0
	 * @param sysUser
	 */
	 List<SysUserVO> list(SysUserDTO sysUser);

    /**
	 * @Description: 分页查询列表
	 * @since V1.0
	 * @param sysUser
	 */
	 PageData<SysUserVO> page(SysUserPageDTO sysUser);

    /**
	 * @Description: 通过ID查询
	 * @since V1.0
	 * @param id
	 */
	 SysUserVO findById(String id);

}