package com.ccb.cloud.metadata.sysuser.dto;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import com.ccb.cloud.metadata.sysuser.dto.SysUserDTO;

/**
 * @author hwr
 * @version 1.0
 * @Description SysUserPageDTO
 * @date 2020-11-23
 */
@Data
public class SysUserPageDTO extends SysUserDTO  {
    @NotNull(message = "limit不为空")
    private Integer limit;

    @NotNull(message = "pageNo不为空")
    private Integer pageNo;
}