package com.ccb.cloud.metadata.sysuser.dto;

import lombok.Data;
import java.util.Date;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.NotBlank;

/**
 * @author hwr
 * @version 1.0
 * @Description SysUserDTO
 * @date 2020-11-23
 */
@Data
public class SysUserDTO {
/** 
 *ID 
 */ 
@NotNull(message = "userId不能为空")
private Long userId;

/** 
 *部门名称 
 */ 
@NotNull(message = "deptId不能为空")
private Long deptId;

/** 
 *用户名 
 */ 
@NotBlank(message = "username不能为空")
private String username;

/** 
 *昵称 
 */ 
@NotBlank(message = "nickName不能为空")
private String nickName;

/** 
 *性别 
 */ 
@NotBlank(message = "gender不能为空")
private String gender;

/** 
 *手机号码 
 */ 
@NotBlank(message = "phone不能为空")
private String phone;

/** 
 *邮箱 
 */ 
@NotBlank(message = "email不能为空")
private String email;

/** 
 *头像地址 
 */ 
@NotBlank(message = "avatarName不能为空")
private String avatarName;

/** 
 *头像真实路径 
 */ 
@NotBlank(message = "avatarPath不能为空")
private String avatarPath;

/** 
 *密码 
 */ 
@NotBlank(message = "password不能为空")
private String password;

/** 
 *是否为admin账号 
 */ 
@NotNull(message = "isAdmin不能为空")
private Integer isAdmin;

/** 
 *状态：1启用、0禁用 
 */ 
@NotNull(message = "enabled不能为空")
private Long enabled;

/** 
 *创建者 
 */ 
@NotBlank(message = "createBy不能为空")
private String createBy;

/** 
 *更新着 
 */ 
@NotBlank(message = "updateBy不能为空")
private String updateBy;

/** 
 *修改密码的时间 
 */ 
@NotNull(message = "pwdResetTime不能为空")
private Date pwdResetTime;

/** 
 *创建日期 
 */ 
@NotNull(message = "createTime不能为空")
private Date createTime;

/** 
 *更新时间 
 */ 
@NotNull(message = "updateTime不能为空")
private Date updateTime;


}