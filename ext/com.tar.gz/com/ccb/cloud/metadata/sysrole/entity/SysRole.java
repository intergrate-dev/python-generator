package com.ccb.cloud.metadata.sysrole.entity; import lombok.Data; import java.util.Date; import javax.validation.constraints.NotNull; import javax.validation.constraints.NotBlank; /** * @author hwr * @version 1.0 * @Description SysRole * @date 2020-11-23 */ public
class SysRole { /** 
 *ID 
 */ 
private Long roleId;

/** 
 *名称 
 */ 
private String name;

/** 
 *角色级别 
 */ 
private Integer level;

/** 
 *描述 
 */ 
private String description;

/** 
 *数据权限 
 */ 
private String dataScope;

/** 
 *创建者 
 */ 
private String createBy;

/** 
 *更新者 
 */ 
private String updateBy;

/** 
 *创建日期 
 */ 
private Date createTime;

/** 
 *更新时间 
 */ 
private Date updateTime;

 }