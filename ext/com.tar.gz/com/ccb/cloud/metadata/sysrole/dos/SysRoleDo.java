package com.ccb.cloud.metadata.sysrole.dos;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.ccb.cloud.data.dos.BaseDos;
import com.ccb.cloud.metadata.sysrole.vo.SysRoleVo;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.cloud.basic.common.consts.ErrorCodeEnum;

public class SysRoleDo extends BaseDos {
    private Logger log = LoggerFactory.getLogger(SysRoleDo.class);

    /** 
 *名称 
 */ 
private String name;

/** 
 *角色级别 
 */ 
private Integer level;

/** 
 *描述 
 */ 
private String description;

/** 
 *数据权限 
 */ 
private String dataScope;

/** 
 *创建者 
 */ 
private String createBy;

/** 
 *更新者 
 */ 
private String updateBy;

/** 
 *创建日期 
 */ 
private Date createTime;

/** 
 *更新时间 
 */ 
private Date updateTime;

      

    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }
    
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getDataScope() {
        return dataScope;
    }

    public void setDataScope(String dataScope) {
        this.dataScope = dataScope;
    }
    
    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }
    
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }
    
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    
    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
      

	public int insertSysRole() throws Exception {
        int i = 0;
        try{
            i = _dao.insertBySqlMap_mybatis("portal.sysRole.insert", this);
        } catch (Exception e) {
            log.error("insert sysRole failure, message: {}", e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "插入角色表数据失败");
        }
        return i;
	}

    public int queryDataCount(Map<String, Object> map) throws Exception {
        int count = 0;
        try{
            count = (Integer) _dao.findObjectBySqlMap_mybatis("portal.sysRole.queryCount", map);
        } catch (Exception ex) {
            log.error("queryDataCount sysRole failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询角色表数据失败");
        }
        return count;
	}

    public List<SysRoleVo> queryDataList(Map<String, Object> map) throws Exception {
        List<SysRoleVo> list = null;
        try{
            list = (List<SysRoleVo>) _dao.findListBySqlMap_mybatis("portal.sysRole.queryListByMap", map);
        } catch (Exception ex) {
            log.error("queryDataList sysRole failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询角色表数据失败");
        }
        return list;
	}

    public SysRoleVo queryDetail(Map<String, Object> map) throws Exception {
        List<SysRoleVo> list = null;
        try{
            list = (List<SysRoleVo>) _dao.findListBySqlMap_mybatis("portal.sysRole.queryListByMap", map);
        } catch (Exception ex) {
            log.error("queryDetail sysRole failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询角色表数据失败");
        }
        return list == null || list.size() == 0 ? null : list.get(0);
	}

    public SysRoleDo findById(String id) throws Exception {
        List<SysRoleDo> list = null;
        try{
            Map map = new HashMap();
            map.put("role_id", id);
            list = (List<SysRoleDo>) _dao.findListBySqlMap_mybatis("portal.sysRole.findById", map);
        } catch (Exception ex) {
            log.error("findById sysRole failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "查询角色表数据失败");
        }
        return list == null || list.size() == 0 ? null : list.get(0);
	}

    public void updateSysRole(Map<String, String> map) throws Exception {
        try{
            _dao.updateBySqlMap_mybatis("portal.sysRole.updateByMap", map);
        } catch (Exception ex) {
            log.error("updateSysRole sysRole failure, message: {}", ex.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.DB_OPERATION_ERR.getCode(), "更新角色表数据失败");
        }
    }
        
}