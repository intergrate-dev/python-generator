package com.ccb.cloud.metadata.sysrole.service.impl;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import com.alibaba.fastjson.JSONObject;
import com.ccb.cloud.metadata.sysrole.dos.SysRoleDo;
import com.ccb.cloud.metadata.sysrole.vo.SysRoleVo;
import com.ccb.cloud.metadata.sysrole.service.SysRoleService;
import com.ccb.cloud.log.Logger;
import com.ccb.cloud.log.LoggerFactory;
import com.ccb.openframework.exception.CommonRuntimeException;
import com.ccb.cloud.basic.common.consts.ErrorCodeEnum;
import com.ccb.cloud.basic.common.entity.ComInfoEntity;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("portal.SysRoleService")
public class SysRoleServiceImpl implements SysRoleService {
    private Logger log = LoggerFactory.getLogger(SysRoleServiceImpl.class);
    
    @Autowired
    SysRoleService sysRoleService;
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String createSysRole(String jsonString) throws Exception {
        SysRoleDo sysRoleDo = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            sysRoleDo = JSONObject.parseObject(body.getString("sysRole"), SysRoleDo.class);
            Map doMap = JSONObject.parseObject(body.getString("sysRole"), HashMap.class);
            sysRoleDo.setRoleId(String.valueOf(System.currentTimeMillis()));
            sysRoleDo.insertSysRole();
            
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "创建成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("create sysRole occure exception, roleId: {}, error: {}", sysRoleDo.getRoleId(), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "创建角色表失败");
        }
    }
    
    @Override
    public String getList(String jsonString) throws Exception {
        try{
            ComInfoEntity common = getReqTxnComm(jsonString);
            JSONObject rtc = new JSONObject();
            rtc.put("stsTraceId", common.gettStsTraceId());
            rtc.put("tCurrTotalPage", common.gettPageJump());
            rtc.put("tCurrTotalRec", common.gettRecInPage());
            Map<String, Object> map = new HashMap();
            Integer pageNo = common.gettPageJump() == null ? 1 : common.gettPageJump();
            Integer pageSize = common.gettRecInPage() == null ? 10 : common.gettRecInPage();
            map.put("tPageJump", (pageNo - 1) * pageSize);
            map.put("tRecInPage", pageSize);
            SysRoleDo sysRoleDo = new SysRoleDo();
            int total = sysRoleDo.queryDataCount(map);
            List<SysRoleVo> dataList = sysRoleDo.queryDataList(map);

            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            this.setPage(common, rtc, total);
            return getObject(rtc, dataList);
        } catch(Exception e) {
            log.info("getList sysRole occure exception, error: {}", e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询角色表列表失败");
        }
    }

    @Override
    public String getDetail(String jsonString) throws Exception {
        String roleId = null;
        try{
            ComInfoEntity common = getReqTxnComm(jsonString);
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            roleId = body.getString("roleId");

            Map<String, Object> map = new HashMap<>();
            map.put("role_id", roleId);
            com.ccb.cloud.metadata.sysrole.vo.SysRoleVo detail = new SysRoleDo().queryDetail(map);
            return getObject(jsonCommon, detail);
        } catch(Exception e) {
            log.info("getDetail sysRole occure exception, roleId: {}, error: {}", roleId, e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "查询角色表详情失败");
        }
    }
    
    public SysRoleDo getSysRoleById(String id) throws Exception {
        return new SysRoleDo().findById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String update(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("sysRole"), HashMap.class);

            new SysRoleDo().updateSysRole(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "修改成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("update sysRole occure exception, roleId: {}, error: {}", doMap.get("role_id"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "修改角色表信息失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String publish(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("sysRole"), HashMap.class);
            doMap.put("state", "1");
            new SysRoleDo().updateSysRole(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "发布成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("publish sysRole occure exception, roleId: {}, error: {}", doMap.get("role_id"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "发布角色表失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String revocate(String jsonString) throws Exception {
        Map doMap = null;
        try{
            JSONObject request = JSONObject.parseObject(jsonString);
            JSONObject body = JSONObject.parseObject(request.getString("txnBodyCom"));
            ComInfoEntity common = getReqTxnComm(jsonString);
            doMap = JSONObject.parseObject(body.getString("sysRole"), HashMap.class);
            doMap.put("state", "0");
            new SysRoleDo().updateSysRole(doMap);
            JSONObject jsonCommon = new JSONObject();
            jsonCommon.put("tStsTraceId", common.gettStsTraceId());
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("message", "注销成功");
            return getObject(jsonCommon, jsonBody);
        } catch(Exception e) {
            log.info("revocate sysRole occure exception, roleId: {}, error: {}", doMap.get("role_id"), e.getMessage());
            throw new CommonRuntimeException(ErrorCodeEnum.COM_DYNAMIC_ERROR.getCode(), "注销角色表失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String delete(String jsonString) throws Exception {
        return null;
    }

    private ComInfoEntity getReqTxnComm(String jsonString) {
        JSONObject request = JSONObject.parseObject(jsonString);
        return JSONObject.parseObject(request.getString("txnCommCom"), ComInfoEntity.class);
    }

    private String getObject(Object common, Object body) {
        JSONObject result = new JSONObject();
        result.put("txnCommCom", common);
        result.put("txnBodyCom", body);
        return result.toString();
    }

    private void setPage(ComInfoEntity common, JSONObject rtc, Integer total) {
        Integer pageSize = common.gettRecInPage();
        rtc.put("totalPage", String.valueOf((total + pageSize - 1)/ pageSize));
        rtc.put("totalRec", String.valueOf(total));
    }

}
