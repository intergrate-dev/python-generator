package com.ccb.cloud.metadata.sysrole.service;


import com.ccb.cloud.metadata.sysrole.dos.SysRoleDo;

public interface SysRoleService {
    
    /**
     * 插入角色表
     *
     * @param jsonString
     * @return
     */
    public String createSysRole(String jsonString) throws Exception;
    
    /**
     * 分页查询角色表
     *
     * @param jsonString
     * @return
     */
    public String getList(String jsonString) throws Exception;

    /**
     * 查询角色表详情
     *
     * @param jsonString
     * @return
     */
    public String getDetail(String jsonString) throws Exception;
    
    public SysRoleDo getSysRoleById(String id) throws Exception;

    /**
     * 更新角色表
     *
     * @param jsonString
     * @return
     */
    public String update(String jsonString) throws Exception;

    /**
     * 发布角色表
     *
     * @param jsonString
     * @return
     */
    public String publish(String jsonString) throws Exception;

    /**
     * 注销角色表
     *
     * @param jsonString
     * @return
     */
    public String revocate(String jsonString) throws Exception;

    /**
     * 删除角色表
     *
     * @param jsonString
     * @return
     */
    public String delete(String jsonString) throws Exception;

}